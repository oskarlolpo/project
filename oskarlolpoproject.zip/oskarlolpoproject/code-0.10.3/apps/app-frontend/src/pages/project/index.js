import Index from './Index.vue'
import Description from './Description.vue'
import Versions from './Versions.vue'
import Gallery from './Gallery.vue'
import Version from './Version.vue'

export { Index, Description, Versions, Gallery, Version }
