<template>
  <div></div>
</template>

<script>
export default {
  name: 'Changelog',
}
</script>

<style scoped></style>
