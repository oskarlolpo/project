<script setup lang="ts"></script>
<template>
  <div class="p-6 flex flex-col gap-2">Worlds</div>
</template>
