<template><slot id="main" /></template>
<style lang="scss">
@import "~/assets/styles/global.scss";
</style>
