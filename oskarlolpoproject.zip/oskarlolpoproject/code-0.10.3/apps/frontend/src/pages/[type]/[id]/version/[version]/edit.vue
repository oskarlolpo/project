<template>
  <div />
</template>
<script setup>
definePageMeta({
  middleware: "auth",
});
</script>
