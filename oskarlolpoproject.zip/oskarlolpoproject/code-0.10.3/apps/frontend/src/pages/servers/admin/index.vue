<template>
  <div class="flex h-full w-full flex-col">
    <div
      class="flex items-center justify-between gap-2 border-0 border-b border-solid border-bg-raised p-3"
    >
      <h2 class="m-0 text-2xl font-bold text-contrast">Admin</h2>
    </div>
  </div>
</template>

<script setup lang="ts"></script>
