<template>
  <div class="markdown-body">
    <h1>Rewards Program Terms</h1>
    <p>
      These REWARDS PROGRAM TERMS ("Terms") constitute a legally binding agreement between you (or
      the entity you represent) ("you") and Rinth, Inc. ("Rinth") concerning your participation in
      the Modrinth Rewards Program (the "Rewards Program").
    </p>
    <p>
      The Rewards Program provides developers and content creators an opportunity to monetize the
      projects ("Projects") that they upload to the Modrinth website.
    </p>
    <p>
      These Terms are in addition to and do not in any manner limit the applicability of the
      <nuxt-link to="/legal/terms">Terms of Use</nuxt-link>, the
      <nuxt-link to="/legal/rules">Content Rules</nuxt-link>, or the
      <nuxt-link to="/legal/privacy">Privacy Policy</nuxt-link>.
    </p>

    <h2>Economics</h2>
    <p>
      Rinth shall pay to you the percentage set forth
      <nuxt-link to="/legal/cmp-info">here</nuxt-link> of net revenue collected by Rinth
      attributable to ad impressions displayed on modrinth.com and the Modrinth App excluding
      transaction fees ("Revenue Share"). Rinth shall make Revenue Share payments to you when you
      withdraw funds from Rinth's dashboard. Rinth shall include with each such payment either
      access to a dashboard or other reasonable reporting detailing the calculation thereof.
    </p>

    <h2>Relationship</h2>
    <p>
      Your relationship with Rinth relating to the Rewards Program is that of an independent
      contractor. In participating in the Rewards Program, you will not be deemed an employee of
      Rinth, you are not eligible for any Rinth employee benefits, and you are solely responsible
      for determining and paying any taxes applicable to amounts paid to you by Rinth hereunder. You
      agree to indemnify and hold harmless Rinth from and against any claim that Rinth is
      responsible for payment of any such taxes.
    </p>

    <h2>Disclaimer Regarding Rewards Program</h2>
    <p>
      YOUR PARTICIPATION IN THE REWARDS PROGRAM IS AT YOUR OWN RISK. THE REWARDS PROGRAM IS PROVIDED
      ON AN "AS IS" AND "AS AVAILABLE" BASIS. TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW,
      RINTH EXPRESSLY DISCLAIMS ALL WARRANTIES OF ANY KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING,
      BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
      PURPOSE AND NON-INFRINGEMENT. RINTH MAKES NO WARRANTY THAT (I) THE REWARDS PROGRAM WILL MEET
      YOUR REQUIREMENTS, (II) THE REWARDS PROGRAM WILL GENERATE ANY MINIMUM REVENUE, AND/OR (III)
      THE REWARDS PROGRAM WILL BE UNINTERRUPTED, TIMELY, SECURE, OR ERROR-FREE.
    </p>

    <h2>Limitation of Liability</h2>
    <p>
      YOU ACKNOWLEDGE AND AGREE THAT, TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW, (A) RINTH
      WILL NOT BE LIABLE TO YOU FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR EXEMPLARY
      DAMAGES, WHICH YOU MAY INCUR, EVEN IF RINTH HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
      DAMAGES, ARISING OUT OF OR IN CONNECTION WITH THE REWARDS PROGRAM OR THESE TERMS AND (B) RINTH
      WILL NOT BE LIABLE TO YOU FOR MORE THAN THE AMOUNT YOU RECEIVED IN CONNECTION WITH THE REWARDS
      PROGRAM IN THE SIX MONTHS PRIOR TO THE TIME YOUR CAUSE OF ACTION AROSE.
    </p>

    <h2>Governing Law</h2>
    <p>
      These Terms shall be governed by and construed in accordance with the internal laws of the
      State of Delaware.
    </p>

    <h2>Termination</h2>
    <p>
      Rinth reserves the right, in our sole discretion and without notice or liability, to terminate
      these Terms or modify or cease to offer the Rewards Program at any time, to any person, for
      any reason or no reason.
    </p>
  </div>
</template>

<script setup>
const description =
  "The Rewards Program Terms of Modrinth, an open source modding platform focused on Minecraft.";

useSeoMeta({
  title: "Rewards Program Terms - Modrinth",
  description,
  ogTitle: "Rewards Program Terms",
  ogDescription: description,
});
</script>
