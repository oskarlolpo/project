declare module "fuse.js/dist/fuse.basic" {
  import Fuse from "fuse.js";
  export default Fuse;
}
