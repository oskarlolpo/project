export function useTheme() {
  return useNuxtApp().$theme;
}

export function useCosmetics() {
  return useNuxtApp().$cosmetics;
}
