export { useRoute as useNativeRoute, useRouter as useNativeRouter } from "vue-router";
