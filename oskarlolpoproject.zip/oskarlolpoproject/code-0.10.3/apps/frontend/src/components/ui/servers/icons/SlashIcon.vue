<template>
  <svg height="32" viewBox="0 0 32 32" width="32">
    <path
      d="M22 5L9 28"
      stroke="currentColor"
      stroke-linecap="round"
      stroke-linejoin="round"
    ></path>
  </svg>
</template>
