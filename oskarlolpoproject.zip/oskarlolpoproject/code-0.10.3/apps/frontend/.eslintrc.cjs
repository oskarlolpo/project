module.exports = {
  root: true,
  extends: ["../../packages/eslint-config-custom/nuxt.js"],
  rules: {
    "import/no-unresolved": "off",
  },
};
